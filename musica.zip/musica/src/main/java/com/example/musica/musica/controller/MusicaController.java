package com.example.musica.musica.controller;

import com.example.musica.musica.model.Musica;
import com.example.musica.musica.service.MusicaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/musicas")
public class MusicaController {

    @Autowired
    private MusicaService musicaService;

    @GetMapping
    public List<Musica> findAll() {
        return musicaService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Musica> findById(@PathVariable Long id) {
        Musica musica = musicaService.findById(id);
        return musica != null ? ResponseEntity.ok(musica) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public Musica save(@RequestBody Musica musica) {
        return musicaService.save(musica);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        musicaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}