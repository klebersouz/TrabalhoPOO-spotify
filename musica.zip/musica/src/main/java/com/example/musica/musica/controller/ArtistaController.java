package com.example.musica.musica.controller;

import com.example.musica.musica.model.Artista;
import com.example.musica.musica.service.ArtistaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/artistas")
public class ArtistaController {

    @Autowired
    private ArtistaService artistaService;

    @GetMapping
    public List<Artista> findAll() {
        return artistaService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Artista> findById(@PathVariable Long id) {
        Artista artista = artistaService.findById(id);
        return artista != null ? ResponseEntity.ok(artista) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public Artista save(@RequestBody Artista artista) {
        return artistaService.save(artista);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        artistaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}