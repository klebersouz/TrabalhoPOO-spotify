package com.example.musica.musica.service;

import com.example.musica.musica.model.Musica;
import com.example.musica.musica.repository.MusicaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MusicaService {

    @Autowired
    private MusicaRepository musicaRepository;

    public List<Musica> findAll() {
        return musicaRepository.findAll();
    }

    public Musica findById(Long id) {
        return musicaRepository.findById(id).orElse(null);
    }

    public Musica save(Musica musica) {
        return musicaRepository.save(musica);
    }

    public void delete(Long id) {
        musicaRepository.deleteById(id);
    }
}