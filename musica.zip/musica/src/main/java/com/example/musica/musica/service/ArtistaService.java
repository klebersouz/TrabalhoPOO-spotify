package com.example.musica.musica.service;

import com.example.musica.musica.model.Artista;
import com.example.musica.musica.repository.ArtistaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArtistaService {

    @Autowired
    private ArtistaRepository artistaRepository;

    public List<Artista> findAll() {
        return artistaRepository.findAll();
    }

    public Artista findById(Long id) {
        return artistaRepository.findById(id).orElse(null);
    }

    public Artista save(Artista artista) {
        return artistaRepository.save(artista);
    }

    public void delete(Long id) {
        artistaRepository.deleteById(id);
    }
}