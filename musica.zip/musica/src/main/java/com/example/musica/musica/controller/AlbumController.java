package com.example.musica.musica.controller;

import com.example.musica.musica.model.Album;
import com.example.musica.musica.service.AlbumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/albuns")
public class AlbumController {

    @Autowired
    private AlbumService albumService;

    @GetMapping
    public List<Album> findAll() {
        return albumService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Album> findById(@PathVariable Long id) {
        Album album = albumService.findById(id);
        return album != null ? ResponseEntity.ok(album) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public Album save(@RequestBody Album album) {
        return albumService.save(album);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        albumService.delete(id);
        return ResponseEntity.noContent().build();
    }
}